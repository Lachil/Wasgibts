import React, {Component} from 'react';
import {Text, View, StyleSheet} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {Spinner} from './common';
import { TOKEN } from './redux';


class StartPage extends Component{

    constructor(){
        super();
    }
    
    componentDidMount() {
        AsyncStorage.getItem(TOKEN).then((token) => {
            if (token) {
                this._navigate('Home');
              }else {
                this._navigate('Login');
              }
        }) 
      }

      _navigate(screen) {
        setTimeout(() => {
          this.props.navigation.navigate(screen);
        }, 1000 );
    
      }


    render(){
        return(
            <View style={styles.view}>
              <Text style={styles.subTitle} >Willkomen zu unsere App</Text>
               <Text style={styles.title}>Was Gibt's</Text>
                <Spinner />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    view:{
        height:80,
        alignItems: 'center',
        justifyContent: 'center',
        flex:2
    },subTitle:{
        fontSize: 14
    },title:{
        fontSize: 48
    }
});

export default StartPage;